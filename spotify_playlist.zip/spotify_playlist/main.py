"""
Spotify Playlist Data Pipeline

This script fetches playlist data from a JSON source, transforms it,
and stores the results locally as CSV files.
"""

import requests
import pandas as pd


# ============================================================
# Step 1: Fetch Playlist Data
# ============================================================

def fetch_playlist_data():
    """Fetch playlist data from JSON URL and return as DataFrame."""
    url = "https://raw.githubusercontent.com/rushi4git/spotify-playlist-data/refs/heads/main/spotify_playlist.json"
    
    print("Fetching data from JSON...")
    response = requests.get(url)
    response.raise_for_status()  # Raise error if request fails
    
    data = response.json()
    
    # The JSON has a 'tracks' column containing a list of track dictionaries
    # Extract the tracks list and convert to DataFrame
    playlist_data = data[0] if isinstance(data, list) else data
    tracks = playlist_data.get('tracks', [])
    df = pd.DataFrame(tracks)
    
    print(f"Successfully fetched {len(df)} tracks")
    return df


# ============================================================
# Step 2: Transform Data
# ============================================================

def transform_data(df):
    """Clean and enrich the playlist data."""
    print("Transforming data...")
    
    # Convert duration from milliseconds to minutes
    df['duration_minutes'] = df['duration_ms'] / 60000
    
    # Extract release year from release date
    df['release_year'] = pd.to_datetime(df['release_date']).dt.year
    
    # Remove duplicate tracks
    df = df.drop_duplicates(subset=['track_name', 'artist_name'])
    print(f"After removing duplicates: {len(df)} tracks")
    
    # Handle missing values - remove rows with missing essential fields
    df = df.dropna(subset=['track_name', 'artist_name', 'popularity'])
    print(f"After removing NaN values: {len(df)} tracks")
    
    # Create popularity_category column
    def categorize_popularity(pop):
        if pop <= 40:
            return 'Low'
        elif pop <= 70:
            return 'Medium'
        else:
            return 'High'
    
    df['popularity_category'] = df['popularity'].apply(categorize_popularity)
    
    return df


# ============================================================
# Bonus Transformations
# ============================================================

def get_bonus_analytics(df):
    """Generate bonus analytics from the data."""
    print("\n=== Bonus Analytics ===")
    
    # Count number of tracks per artist
    artist_count = df.groupby('artist_name').size().sort_values(ascending=False)
    print(f"\nTracks per artist (top 10):\n{artist_count.head(10)}")
    
    # Calculate average track duration
    avg_duration = df['duration_minutes'].mean()
    print(f"\nAverage track duration: {avg_duration:.2f} minutes")
    
    # Find top 5 most popular tracks
    top_tracks = df.sort_values(by='popularity', ascending=False).head(5)
    print(f"\nTop 5 most popular tracks:")
    print(top_tracks[['track_name', 'artist_name', 'popularity']])
    
    # Identify most frequent artist
    most_frequent_artist = df['artist_name'].value_counts().idxmax()
    print(f"\nMost frequent artist: {most_frequent_artist}")
    
    return {
        'artist_count': artist_count,
        'avg_duration': avg_duration,
        'top_tracks': top_tracks,
        'most_frequent_artist': most_frequent_artist
    }


# ============================================================
# Step 3: Store Data Locally
# ============================================================

def save_data(df_raw, df_transformed):
    """Save raw and transformed data to CSV files."""
    print("\nSaving data to CSV files...")
    
    # Save raw data
    df_raw.to_csv('playlist_raw.csv', index=False)
    print("Saved: playlist_raw.csv")
    
    # Save transformed data
    df_transformed.to_csv('playlist_transformed.csv', index=False)
    print("Saved: playlist_transformed.csv")


def save_summary_report(df, analytics):
    """Save a summary report with statistics."""
    print("\nSaving summary report...")
    
    with open('summary_report.txt', 'w') as f:
        f.write("=" * 50 + "\n")
        f.write("SPOTIFY PLAYLIST DATA PIPELINE - SUMMARY REPORT\n")
        f.write("=" * 50 + "\n\n")
        
        f.write(f"Total tracks in raw data: {len(df)}\n")
        f.write(f"Average track duration: {analytics['avg_duration']:.2f} minutes\n")
        f.write(f"Most frequent artist: {analytics['most_frequent_artist']}\n\n")
        
        f.write("Popularity Distribution:\n")
        f.write(df['popularity_category'].value_counts().to_string() + "\n\n")
        
        f.write("Top 5 Most Popular Tracks:\n")
        for idx, row in analytics['top_tracks'].iterrows():
            f.write(f"  - {row['track_name']} by {row['artist_name']} (popularity: {row['popularity']})\n")
        
        f.write("\nTop 10 Artists by Track Count:\n")
        f.write(analytics['artist_count'].head(10).to_string())
    
    print("Saved: summary_report.txt")


# ============================================================
# Main Pipeline
# ============================================================

def run_pipeline():
    """Execute the complete data pipeline."""
    print("=" * 50)
    print("SPOTIFY PLAYLIST DATA PIPELINE")
    print("=" * 50 + "\n")
    
    # Step 1: Fetch data
    df_raw = fetch_playlist_data()
    
    # Save raw data before transformation
    df_raw.to_csv('playlist_raw.csv', index=False)
    print(f"Raw data saved: {len(df_raw)} tracks\n")
    
    # Step 2: Transform data
    df_transformed = transform_data(df_raw.copy())
    
    # Get bonus analytics
    analytics = get_bonus_analytics(df_transformed)
    
    # Step 3: Save transformed data
    df_transformed.to_csv('playlist_transformed.csv', index=False)
    print(f"\nTransformed data saved: {len(df_transformed)} tracks")
    
    # Save summary report
    save_summary_report(df_transformed, analytics)
    
    print("\n" + "=" * 50)
    print("PIPELINE COMPLETE!")
    print("=" * 50)
    print("\nOutput files:")
    print("  - playlist_raw.csv")
    print("  - playlist_transformed.csv")
    print("  - summary_report.txt")


if __name__ == "__main__":
    run_pipeline()

