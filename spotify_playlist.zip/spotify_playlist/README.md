# Spotify Playlist Data Pipeline

A mini data pipeline that fetches playlist data, transforms and cleans it, and stores the results locally for analysis.

## Project Overview

This pipeline acts like a data engineering workflow:

```
Raw Data (JSON) → Transformation → Clean CSV → Analysis
```

## Dataset Source

- **Source**: JSON file from GitHub
- **URL**: https://raw.githubusercontent.com/rushi4git/spotify-playlist-data/refs/heads/main/spotify_playlist.json

The dataset contains Spotify playlist tracks with information including:
- Track name
- Artist name
- Album
- Popularity score
- Duration (in milliseconds)
- Release date

## Steps to Run the Project

### 1. Install Dependencies

```bash
pip install -r requirements.txt
```

### 2. Run the Pipeline

```bash
python main.py
```

## Pipeline Steps

### Step 1: Fetch Data
- Fetches JSON data from the URL using Python requests
- Converts JSON to Pandas DataFrame

### Step 2: Transform Data
The following transformations are applied:

1. **Duration Conversion**: Converts duration from milliseconds to minutes
2. **Release Year**: Extracts year from release date
3. **Remove Duplicates**: Removes duplicate tracks based on track name and artist
4. **Handle Missing Values**: Removes rows with missing essential fields
5. **Popularity Category**: Creates a category column:
   - 0-40 → Low
   - 41-70 → Medium
   - 71-100 → High

### Step 3: Store Data
Saves two CSV files:
- `playlist_raw.csv` - Original fetched data
- `playlist_transformed.csv` - Cleaned and transformed data
- `summary_report.txt` - Summary statistics

## Bonus Analytics

The pipeline also generates:
- Tracks per artist count
- Average track duration
- Top 5 most popular tracks
- Most frequent artist

## Example Output

```
SPOTIFY PLAYLIST DATA PIPELINE
==================================================

Fetching data from JSON...
Successfully fetched 500 tracks
Transforming data...
After removing duplicates: 495 tracks
After removing NaN values: 495 tracks

=== Bonus Analytics ===

Average track duration: 3.45 minutes

Top 5 most popular tracks:
  Track Name by Artist (popularity: 95)
  ...

Most frequent artist: Artist Name

PIPELINE COMPLETE!
```

## Output Files

After running the pipeline, you will have:

| File | Description |
|------|-------------|
| `playlist_raw.csv` | Original fetched data |
| `playlist_transformed.csv` | Cleaned and enriched data |
| `summary_report.txt` | Summary statistics report |
| `requirements.txt` | Python dependencies |
| `main.py` | Main pipeline script |
| `README.md` | This documentation |

## Requirements

- Python 3.7+
- pandas
- requests

